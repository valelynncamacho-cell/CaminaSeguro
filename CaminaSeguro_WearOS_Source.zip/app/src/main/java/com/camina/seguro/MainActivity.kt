package com.camina.seguro

import android.Manifest
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {
    private val TAG = "CaminaSeguro"
    private val DEVICE_NAME = "ESP32_GaitGuard"
    private val SERVICE_UUID = java.util.UUID.fromString("0000181a-0000-1000-8000-00805f9b34fb")
    private val CHAR_UUID = java.util.UUID.fromString("00002a58-0000-1000-8000-00805f9b34fb")

    private var bluetoothAdapter: BluetoothAdapter? = null
    private var gatt: BluetoothGatt? = null
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var btnConnect: Button
    private lateinit var tvStatus: TextView
    private lateinit var tvAcc: TextView
    private lateinit var tvGyro: TextView
    private lateinit var tvRisk: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnConnect = findViewById(R.id.btn_connect)
        tvStatus = findViewById(R.id.tv_status)
        tvAcc = findViewById(R.id.tv_acc)
        tvGyro = findViewById(R.id.tv_gyro)
        tvRisk = findViewById(R.id.tv_risk)

        val bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = bluetoothManager.adapter

        btnConnect.setOnClickListener {
            if (gatt == null) {
                startScan()
            } else {
                disconnectGatt()
            }
        }

        checkPermissions()
    }

    private fun checkPermissions() {
        val needed = arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.ACCESS_FINE_LOCATION)
        val missing = needed.filter { ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 1001)
        }
    }

    private fun startScan() {
        tvStatus.text = "Escaneando..."
        val scanner = bluetoothAdapter?.bluetoothLeScanner ?: run {
            tvStatus.text = "Bluetooth no disponible"
            return
        }
        scanner.startScan(scanCallback)
        handler.postDelayed({ scanner.stopScan(scanCallback) }, 10000)
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val name = result.device.name ?: ""
            if (name == DEVICE_NAME) {
                bluetoothAdapter?.bluetoothLeScanner?.stopScan(this)
                connectToDevice(result.device)
            }
        }
    }

    private fun connectToDevice(device: BluetoothDevice) {
        tvStatus.text = "Conectando a ${device.name}..."
        gatt = device.connectGatt(this, false, gattCallback)
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            super.onConnectionStateChange(g, status, newState)
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                runOnUiThread { tvStatus.text = "Conectado, descubriendo servicios..." }
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                runOnUiThread { tvStatus.text = "Desconectado" ; tvRisk.text = "Transmisión parada" }
                gatt?.close(); gatt = null
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            super.onServicesDiscovered(g, status)
            val service = g.getService(SERVICE_UUID) ?: run {
                runOnUiThread { tvStatus.text = "Servicio no encontrado" }
                return
            }
            val char = service.getCharacteristic(CHAR_UUID) ?: run {
                runOnUiThread { tvStatus.text = "Característica no encontrada" }
                return
            }
            // Habilitar notificaciones
            g.setCharacteristicNotification(char, true)
            val descriptor = char.getDescriptor(java.util.UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"))
            descriptor?.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            descriptor?.let { g.writeDescriptor(it) }
            runOnUiThread { tvStatus.text = "Suscrito a notificaciones" }
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            super.onCharacteristicChanged(g, characteristic)
            val raw = characteristic.getStringValue(0) ?: return
            parseAndUpdate(raw)
        }
    }

    private fun parseAndUpdate(raw: String) {
        try {
            // formatos: "ax,ay,az:gx,gy,gz" o "ax,ay,az,gx,gy,gz"
            val cleaned = raw.trim()
            val (accPart, gyroPart) = if (cleaned.contains(":")) {
                val parts = cleaned.split(":")
                parts[0] to parts[1]
            } else {
                val parts = cleaned.split(",")
                parts.subList(0,3).joinToString(",") to parts.subList(3,6).joinToString(",")
            }
            val acc = accPart.split(",").map { it.trim().toFloat() }
            val gyro = gyroPart.split(",").map { it.trim().toFloat() }

            val ax = acc[0]; val ay = acc[1]; val az = acc[2]
            val tilt = Math.sqrt((ax*ax + ay*ay + az*az).toDouble()).toFloat()

            runOnUiThread {
                tvAcc.text = "Acelerómetro: ${ax}, ${ay}, ${az}"
                tvGyro.text = "Giroscopio: ${gyro[0]}, ${gyro[1]}, ${gyro[2]}"
                tvRisk.text = riskMessage(tilt)
            }
        } catch (e: Exception) {
            Log.w(TAG, "parse error: ${e.message}")
        }
    }

    private fun riskMessage(tilt: Float): String {
        return when {
            tilt <= 1.02f -> "Marcha estable"
            tilt <= 1.08f -> "Cuidado: ligera inclinación"
            tilt <= 1.15f -> "Riesgo medio"
            else -> "Peligro: posible pérdida de equilibrio"
        }
    }

    private fun disconnectGatt() {
        gatt?.disconnect()
        gatt?.close()
        gatt = null
        runOnUiThread { tvStatus.text = "Desconectado" }
    }
}
