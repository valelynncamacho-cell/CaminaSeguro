Camina Seguro - Instrucciones para compilar e instalar APK en Galaxy Watch4 (Wear OS 5.0)
-----------------------------------------------------------------------------------------------
IMPORTANTE: No puedo compilar el APK aquí, pero te doy el proyecto listo para compilar y las instrucciones para instalar.

1) Requisitos:
   - JDK 11+ y Android SDK (o Android Studio)
   - Conexión PC <-> reloj (ADB por Wi-Fi recomendado)
   - Habilitar modo desarrollador y ADB en el reloj

2) Activar modo desarrollador en el reloj:
   - Ajustes → Acerca del reloj → Información del software → toca 'Número de compilación' 7 veces.
   - Ajustes → Opciones de desarrollador → activa 'Depuración ADB' y 'ADB por Wi‑Fi'. Anota la IP (ej. 192.168.1.45:5555).

3) Compilar APK:
   - Abrir proyecto en Android Studio y Build > Build APK(s) OR
   - Desde la carpeta del proyecto ejecutar: ./gradlew assembleDebug (requiere SDK)

4) Conectar e instalar via ADB:
   - adb connect IP_DEL_RELOJ
   - adb devices  (verás el reloj)
   - adb install -r app/build/outputs/apk/debug/app-debug.apk

Si quieres, puedo intentar compilar el APK por ti usando un servicio CI y entregarte el APK listo. Dime si quieres que haga eso (te lo daría para descargar).