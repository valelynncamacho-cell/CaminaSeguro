rootProject.name = "CaminaSeguro"
include(":app")
